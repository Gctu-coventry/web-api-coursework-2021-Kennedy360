declare module 'assert/strict' {
    import { strict } from 'assert';
    export = strict;
}
