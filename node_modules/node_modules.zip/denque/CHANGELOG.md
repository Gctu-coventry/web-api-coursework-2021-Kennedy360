## 1.5.0

 - feat: adds capacity option for circular buffers (#27)

